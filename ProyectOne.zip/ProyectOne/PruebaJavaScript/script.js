
//declaracion variables
var caja1=document.getElementById("boxOne");
var caja2=document.getElementById("boxTwo");
var caja3=document.getElementById("boxThree");
var caja4=document.getElementById("boxFour");

//declaracion de eventos
var cambio1=document.getElementById("innerBoxOne");
var cambio2=document.getElementById("innerBoxTwo");
var cambio3=document.getElementById("innerBoxThree");
var cambio4=document.getElementById("innerBoxFour");

//funcion

//variable global
var globalVar=false;
//variable auxiliar
var aux=null;
//funcion general
function deployment(object){
    if(globalVar){
        if(object==aux){
            object.classList.remove("activo");
            globalVar=false;
        }
        else{
            aux.classList.remove("activo");
            object.classList.add("activo");
        }
    }
    else{
        globalVar=true;
        object.classList.add("activo");
    }
    aux=object;
}

caja1.addEventListener('click',function(){deployment(cambio1);});
caja2.addEventListener('click',function(){deployment(cambio2);});
caja3.addEventListener('click',function(){deployment(cambio3);});
caja4.addEventListener('click',function(){deployment(cambio4);});
