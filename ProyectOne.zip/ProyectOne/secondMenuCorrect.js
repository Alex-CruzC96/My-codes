var activador1=document.getElementById("button");
var activador2=document.getElementById("arrowLeft");
var activador3=document.getElementById("fullScreenIcon");
var barraLateral=document.getElementById("aside");

//variables globales
var variableGlobal=false;
var auxiliar1=null;
var auxiliar2=null;
var auxiliar3=activador3;
var contador=false;

//funcion
function despliegueBarra(activador,elemento){
    if(variableGlobal){
        if(activador==auxiliar1){
            activador.classList.remove("desplegado");
            elemento.classList.remove("desplegado");
            variableGlobal=false;
        }
        else{
            if(activador==auxiliar3){
                if(contador){
                    contador=false;
                    elemento.classList.remove("fullScreen");
                }
                else{
                    contador=true;
                    elemento.classList.add("fullScreen");
                }
            }
            else{
                if(contador==true){
                    elemento.classList.remove("fullScreen");
                    contador=false;
                }
                auxiliar1.classList.remove("desplegado");
                auxiliar2.classList.remove("desplegado");
                variableGlobal=false;
            }
        }
    }
    else{
        variableGlobal=true;
        elemento.classList.add("desplegado");
        activador.classList.add("desplegado");
    }
    if(activador!==auxiliar3){
        auxiliar1=activador;
        auxiliar2=elemento;
    }
}
activador1.addEventListener('click',function(){despliegueBarra(activador1,barraLateral);});
activador2.addEventListener('click',function(){despliegueBarra(activador2,barraLateral);});
activador3.addEventListener('click',function(){despliegueBarra(activador3,barraLateral);});