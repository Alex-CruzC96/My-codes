//declarando variables activadoras
var butt=document.getElementById("button"); //activadores
var arrow=document.getElementById("arrowLeft");//activadores
var sideBar=document.getElementById("aside");
var full=document.getElementById("fullScreenIcon");

//variables globales
var globalVar=false;
var aux=null;   //guarda al evento
var aux2=null;  //guarda al objeto alterado
var aux3=full;
var cont=false;
//funcion
function deployment(evento,element){ //evento es quien hace desplegar 
    //evalua si hay un evento activo, de haberlo significa que la barra ha sido desplegada
    if(globalVar){
        //en caso de que ya haya un evento activo evalua si el nuevo evento es el mismo
        if(evento==aux){
            //de ser igual simplemente se eliminan las clases de activado
            evento.classList.remove("desplegado");
            element.classList.remove("desplegado");
            //la variable global se torna falsa ya que el evento activo habra terminado
            globalVar=false;
        }
        else{
            //evalua si el evento a ingresar es el boton fullScreen
            if(evento==aux3){
                //de serlo evalua si ya ha sido activado antes
                if(cont){
                    //si ya ha sido activado con anterioridad la variable cont se niega
                    cont=false;
                    //y se elimina la clase fullScreen
                    element.classList.remove("fullScreen");
                }
                else{
                    //si no ha sido activado antes la variable cont se vuelve verdadera
                    cont=true;
                    element.classList.add("fullScreen");
                }   
            }
            else{
                if(cont==true){
                    element.classList.remove("fullScreen");
                    cont=false;
                }
                //de no ser el mismo evento elimina las clases de los eventos anteriores
                aux.classList.remove("desplegado");
                aux2.classList.remove("desplegado");
                globalVar=false;    
            }
        }
    }
    else{
        //de no haber ningun evento activo la variable global se torna cierta 
        globalVar=true;
        //se agregan las respectivas clases
        element.classList.add("desplegado");
        evento.classList.add("desplegado");
    }
    //se guardan los eventos recientes
    if(evento!==aux3){
        aux=evento;
        aux2=element;
    }
}
//llamando a la funcion
butt.addEventListener('click',function(){deployment(butt,sideBar);});
arrow.addEventListener('click',function(){deployment(arrow,sideBar);});
full.addEventListener('click',function(){deployment(full,sideBar);});
